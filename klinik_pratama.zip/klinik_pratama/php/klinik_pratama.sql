-- ============================================================
-- DATABASE: Klinik Pratama Sehat
-- Versi     : 1.0
-- Dibuat    : 2025
-- Deskripsi : Sistem Manajemen Klinik Pratama
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+07:00";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `klinik_pratama`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `klinik_pratama`;

-- ============================================================
-- TABEL: layanan
-- ============================================================
DROP TABLE IF EXISTS `layanan`;
CREATE TABLE `layanan` (
  `id`          VARCHAR(10)  NOT NULL,
  `nama`        VARCHAR(100) NOT NULL,
  `deskripsi`   TEXT,
  `icon`        VARCHAR(60)  DEFAULT NULL,
  `warna`       VARCHAR(30)  DEFAULT NULL,
  `status`      ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: dokter
-- ============================================================
DROP TABLE IF EXISTS `dokter`;
CREATE TABLE `dokter` (
  `id`            VARCHAR(10)  NOT NULL,
  `nama`          VARCHAR(150) NOT NULL,
  `spesialisasi`  VARCHAR(100) NOT NULL,
  `layanan_id`    VARCHAR(10)  DEFAULT NULL,
  `telepon`       VARCHAR(30)  DEFAULT NULL,
  `email`         VARCHAR(100) DEFAULT NULL,
  `hari`          VARCHAR(100) DEFAULT NULL,
  `jam`           VARCHAR(50)  DEFAULT NULL,
  `status`        ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',
  `bio`           TEXT,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_dokter_layanan` FOREIGN KEY (`layanan_id`) REFERENCES `layanan` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: jadwal
-- ============================================================
DROP TABLE IF EXISTS `jadwal`;
CREATE TABLE `jadwal` (
  `id`           VARCHAR(10) NOT NULL,
  `dokter_id`    VARCHAR(10) NOT NULL,
  `dokter_nama`  VARCHAR(150) DEFAULT NULL,
  `hari`         ENUM('Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu') NOT NULL,
  `jam_mulai`    TIME        NOT NULL,
  `jam_selesai`  TIME        NOT NULL,
  `kuota`        SMALLINT    NOT NULL DEFAULT 20,
  `status`       ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',
  `created_at`   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_jadwal_dokter` FOREIGN KEY (`dokter_id`) REFERENCES `dokter` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: pasien
-- ============================================================
DROP TABLE IF EXISTS `pasien`;
CREATE TABLE `pasien` (
  `id`         VARCHAR(20)  NOT NULL,
  `nama`       VARCHAR(150) NOT NULL,
  `nik`        CHAR(16)     NOT NULL,
  `ttl`        DATE         NOT NULL,
  `jk`         ENUM('Laki-laki','Perempuan') NOT NULL,
  `telepon`    VARCHAR(20)  DEFAULT NULL,
  `email`      VARCHAR(100) DEFAULT NULL,
  `alamat`     TEXT,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pasien_nik` (`nik`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: pendaftaran
-- ============================================================
DROP TABLE IF EXISTS `pendaftaran`;
CREATE TABLE `pendaftaran` (
  `id`            VARCHAR(20)  NOT NULL,
  `no_reg`        VARCHAR(20)  NOT NULL,
  `pasien_id`     VARCHAR(20)  NOT NULL,
  `pasien_nama`   VARCHAR(150) DEFAULT NULL,
  `layanan_id`    VARCHAR(10)  DEFAULT NULL,
  `layanan_nama`  VARCHAR(100) DEFAULT NULL,
  `dokter_id`     VARCHAR(10)  DEFAULT NULL,
  `dokter_nama`   VARCHAR(150) DEFAULT NULL,
  `tanggal`       DATE         NOT NULL,
  `keluhan`       TEXT,
  `status`        ENUM('Menunggu','Diproses','Selesai','Batal') NOT NULL DEFAULT 'Menunggu',
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pendaftaran_noreg` (`no_reg`),
  CONSTRAINT `fk_pendaftaran_pasien`  FOREIGN KEY (`pasien_id`)  REFERENCES `pasien`  (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pendaftaran_layanan` FOREIGN KEY (`layanan_id`) REFERENCES `layanan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pendaftaran_dokter`  FOREIGN KEY (`dokter_id`)  REFERENCES `dokter`  (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: rekam_medis
-- ============================================================
DROP TABLE IF EXISTS `rekam_medis`;
CREATE TABLE `rekam_medis` (
  `id`                VARCHAR(20)  NOT NULL,
  `tanggal`           DATE         NOT NULL,
  `pasien_id`         VARCHAR(20)  NOT NULL,
  `pasien_nama`       VARCHAR(150) DEFAULT NULL,
  `dokter_id`         VARCHAR(10)  DEFAULT NULL,
  `dokter_nama`       VARCHAR(150) DEFAULT NULL,
  `layanan_nama`      VARCHAR(100) DEFAULT NULL,
  `diagnosis`         TEXT         NOT NULL,
  `anamnesis`         TEXT,
  `pemeriksaan_fisik` TEXT,
  `tekanan_darah`     VARCHAR(20)  DEFAULT NULL,
  `nadi`              VARCHAR(10)  DEFAULT NULL,
  `suhu`              VARCHAR(10)  DEFAULT NULL,
  `tinggi_badan`      VARCHAR(10)  DEFAULT NULL,
  `berat_badan`       VARCHAR(10)  DEFAULT NULL,
  `tindakan`          TEXT,
  `resep`             TEXT,
  `catatan`           TEXT,
  `created_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_rm_pasien` FOREIGN KEY (`pasien_id`) REFERENCES `pasien`  (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rm_dokter` FOREIGN KEY (`dokter_id`) REFERENCES `dokter`  (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: obat
-- ============================================================
DROP TABLE IF EXISTS `obat`;
CREATE TABLE `obat` (
  `id`         VARCHAR(10)  NOT NULL,
  `nama`       VARCHAR(150) NOT NULL,
  `kategori`   VARCHAR(80)  DEFAULT NULL,
  `satuan`     VARCHAR(30)  DEFAULT NULL,
  `stok`       INT          NOT NULL DEFAULT 0,
  `harga`      DECIMAL(12,0) NOT NULL DEFAULT 0,
  `status`     ENUM('Tersedia','Habis','Nonaktif') NOT NULL DEFAULT 'Tersedia',
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: billing
-- ============================================================
DROP TABLE IF EXISTS `billing`;
CREATE TABLE `billing` (
  `id`                 VARCHAR(20)  NOT NULL,
  `no_bill`            VARCHAR(20)  NOT NULL,
  `pasien_id`          VARCHAR(20)  DEFAULT NULL,
  `pasien_nama`        VARCHAR(150) DEFAULT NULL,
  `pendaftaran_id`     VARCHAR(20)  DEFAULT NULL,
  `layanan_nama`       VARCHAR(100) DEFAULT NULL,
  `dokter_nama`        VARCHAR(150) DEFAULT NULL,
  `tanggal`            DATE         NOT NULL,
  `total_biaya`        DECIMAL(12,0) NOT NULL DEFAULT 0,
  `metode_pembayaran`  VARCHAR(50)  DEFAULT NULL,
  `status`             ENUM('Belum Lunas','Lunas','Dibatalkan') NOT NULL DEFAULT 'Belum Lunas',
  `created_at`         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_billing_nobill` (`no_bill`),
  CONSTRAINT `fk_billing_pasien`       FOREIGN KEY (`pasien_id`)      REFERENCES `pasien`      (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_billing_pendaftaran`  FOREIGN KEY (`pendaftaran_id`) REFERENCES `pendaftaran` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: billing_item  (detail item tagihan)
-- ============================================================
DROP TABLE IF EXISTS `billing_item`;
CREATE TABLE `billing_item` (
  `id`          INT          NOT NULL AUTO_INCREMENT,
  `billing_id`  VARCHAR(20)  NOT NULL,
  `nama`        VARCHAR(150) NOT NULL,
  `jumlah`      INT          NOT NULL DEFAULT 1,
  `harga`       DECIMAL(12,0) NOT NULL DEFAULT 0,
  `subtotal`    DECIMAL(12,0) GENERATED ALWAYS AS (`jumlah` * `harga`) STORED,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_billingitem_billing` FOREIGN KEY (`billing_id`) REFERENCES `billing` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: pesan  (pesan dari pengunjung)
-- ============================================================
DROP TABLE IF EXISTS `pesan`;
CREATE TABLE `pesan` (
  `id`         VARCHAR(20)  NOT NULL,
  `nama`       VARCHAR(150) NOT NULL,
  `email`      VARCHAR(100) DEFAULT NULL,
  `subjek`     VARCHAR(200) DEFAULT NULL,
  `isi_pesan`  TEXT         NOT NULL,
  `sudah_baca` TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABEL: admin_users
-- ============================================================
DROP TABLE IF EXISTS `admin_users`;
CREATE TABLE `admin_users` (
  `id`          VARCHAR(10)  NOT NULL,
  `nama`        VARCHAR(150) NOT NULL,
  `username`    VARCHAR(60)  NOT NULL,
  `password`    VARCHAR(255) NOT NULL COMMENT 'Simpan sebagai bcrypt hash di produksi',
  `role`        ENUM('Superadmin','Administrasi','Perawat','Dokter','Kasir') NOT NULL DEFAULT 'Administrasi',
  `hak_akses`   JSON         DEFAULT NULL COMMENT 'Array menu yang boleh diakses',
  `status`      ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_adminusers_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- DATA: layanan
-- ============================================================
INSERT INTO `layanan` (`id`,`nama`,`deskripsi`,`icon`,`warna`,`status`) VALUES
('l1','Poli Umum','Pelayanan kesehatan dasar, konsultasi keluhan umum, dan pemeriksaan fisik menyeluruh.','medical_services','blue','Aktif'),
('l2','Poli Gigi','Perawatan gigi dan mulut komprehensif, scaling, tambal gigi, dan cabut gigi.','dentistry','green','Aktif'),
('l3','Poli Anak','Layanan kesehatan spesialis untuk tumbuh kembang anak, imunisasi, dan penanganan penyakit.','child_care','purple','Aktif'),
('l4','Laboratorium','Pemeriksaan darah, urin, dan berbagai tes diagnostik medis dengan hasil akurat.','science','yellow','Aktif'),
('l5','Radiologi','Rontgen, USG, dan pemeriksaan radiologi modern dengan teknologi terkini.','radiology','red','Aktif'),
('l6','IGD 24 Jam','Instalasi Gawat Darurat siaga 24 jam untuk penanganan kasus darurat medis.','emergency','orange','Aktif'),
('l7','Poli Kandungan','Layanan kesehatan ibu dan kandungan, pemeriksaan kehamilan, dan USG kebidanan.','pregnant_woman','pink','Aktif'),
('l8','Poli Mata','Pemeriksaan dan perawatan kesehatan mata, refraksi, dan tindakan bedah mata ringan.','visibility','cyan','Aktif');

-- ============================================================
-- DATA: dokter
-- ============================================================
INSERT INTO `dokter` (`id`,`nama`,`spesialisasi`,`layanan_id`,`telepon`,`email`,`hari`,`jam`,`status`,`bio`) VALUES
('d1','dr. Ahmad Santoso','Dokter Umum','l1','0812-1111-2222','ahmad@klinik.id','Senin, Rabu, Jumat','08:00-14:00','Aktif','Dokter umum berpengalaman 10 tahun. Lulus dari Universitas Indonesia dan telah menangani ribuan pasien dengan penuh dedikasi.'),
('d2','dr. Siti Aminah, Sp.A','Spesialis Anak','l3','0812-3333-4444','siti@klinik.id','Selasa, Kamis, Sabtu','09:00-15:00','Aktif','Spesialis anak dengan pengalaman lebih dari 8 tahun. Ahli dalam tumbuh kembang anak dan imunisasi.'),
('d3','drg. Budi Wijaya','Dokter Gigi','l2','0812-5555-6666','budi@klinik.id','Senin, Rabu, Sabtu','10:00-16:00','Aktif','Dokter gigi spesialis restoratif dan estetik dengan keahlian dalam pemasangan implan dan mahkota gigi.'),
('d4','dr. Heru Prasetyo','Dokter Umum Senior','l1','0812-7777-8888','heru@klinik.id','Selasa, Jumat','07:00-13:00','Aktif','Dokter umum senior dengan 15 tahun pengalaman. Spesialis dalam penanganan penyakit dalam dan manajemen penyakit kronis.'),
('d5','dr. Rina Kusuma, Sp.Rad','Radiologi','l5','0812-9999-0000','rina@klinik.id','Senin s.d. Jumat','08:00-17:00','Aktif','Ahli radiologi terpercaya dengan keahlian dalam interpretasi USG, rontgen, dan CT-Scan.'),
('d6','dr. Dewi Lestari, Sp.OG','Spesialis Kandungan','l7','0813-1111-2233','dewi@klinik.id','Senin, Rabu, Jumat','09:00-15:00','Aktif','Spesialis kebidanan dan kandungan dengan pengalaman 12 tahun. Berpengalaman dalam persalinan normal dan cesar.'),
('d7','dr. Fajar Nugroho, Sp.M','Spesialis Mata','l8','0813-4444-5566','fajar@klinik.id','Selasa, Kamis','10:00-15:00','Aktif','Spesialis mata dengan keahlian dalam bedah katarak, lasik, dan penanganan glaukoma.'),
('d8','drg. Ratna Sari','Dokter Gigi Umum','l2','0813-7777-8899','ratna@klinik.id','Senin, Kamis, Sabtu','08:00-14:00','Aktif','Dokter gigi dengan minat khusus di bidang ortodonti dan perawatan gigi anak.');

-- ============================================================
-- DATA: jadwal
-- ============================================================
INSERT INTO `jadwal` (`id`,`dokter_id`,`dokter_nama`,`hari`,`jam_mulai`,`jam_selesai`,`kuota`,`status`) VALUES
('j1','d1','dr. Ahmad Santoso','Senin','08:00','14:00',20,'Aktif'),
('j2','d1','dr. Ahmad Santoso','Rabu','08:00','14:00',20,'Aktif'),
('j3','d1','dr. Ahmad Santoso','Jumat','08:00','13:00',15,'Aktif'),
('j4','d2','dr. Siti Aminah, Sp.A','Selasa','09:00','15:00',15,'Aktif'),
('j5','d2','dr. Siti Aminah, Sp.A','Kamis','09:00','15:00',15,'Aktif'),
('j6','d2','dr. Siti Aminah, Sp.A','Sabtu','08:00','12:00',10,'Aktif'),
('j7','d3','drg. Budi Wijaya','Senin','10:00','16:00',12,'Aktif'),
('j8','d3','drg. Budi Wijaya','Rabu','10:00','16:00',12,'Aktif'),
('j9','d3','drg. Budi Wijaya','Sabtu','09:00','13:00',8,'Aktif'),
('j10','d4','dr. Heru Prasetyo','Selasa','07:00','13:00',18,'Aktif'),
('j11','d4','dr. Heru Prasetyo','Jumat','07:00','13:00',18,'Aktif'),
('j12','d5','dr. Rina Kusuma, Sp.Rad','Senin','08:00','17:00',25,'Aktif'),
('j13','d5','dr. Rina Kusuma, Sp.Rad','Selasa','08:00','17:00',25,'Aktif'),
('j14','d5','dr. Rina Kusuma, Sp.Rad','Rabu','08:00','17:00',25,'Aktif'),
('j15','d5','dr. Rina Kusuma, Sp.Rad','Kamis','08:00','17:00',25,'Aktif'),
('j16','d5','dr. Rina Kusuma, Sp.Rad','Jumat','08:00','17:00',25,'Aktif'),
('j17','d6','dr. Dewi Lestari, Sp.OG','Senin','09:00','15:00',12,'Aktif'),
('j18','d6','dr. Dewi Lestari, Sp.OG','Rabu','09:00','15:00',12,'Aktif'),
('j19','d6','dr. Dewi Lestari, Sp.OG','Jumat','09:00','13:00',8,'Aktif'),
('j20','d7','dr. Fajar Nugroho, Sp.M','Selasa','10:00','15:00',10,'Aktif'),
('j21','d7','dr. Fajar Nugroho, Sp.M','Kamis','10:00','15:00',10,'Aktif'),
('j22','d8','drg. Ratna Sari','Senin','08:00','14:00',10,'Aktif'),
('j23','d8','drg. Ratna Sari','Kamis','08:00','14:00',10,'Aktif'),
('j24','d8','drg. Ratna Sari','Sabtu','08:00','12:00',8,'Aktif');

-- ============================================================
-- DATA: pasien
-- ============================================================
INSERT INTO `pasien` (`id`,`nama`,`nik`,`ttl`,`jk`,`telepon`,`email`,`alamat`) VALUES
('p1','Budi Santoso','3271011234567890','1985-05-12','Laki-laki','0812-0001-0001','budi.s@email.com','Jl. Melati No. 10, Jakarta Selatan'),
('p2','Sri Wahyuni','3271025678901234','1990-08-25','Perempuan','0812-0002-0002','sri.w@email.com','Jl. Mawar No. 5, Depok'),
('p3','Rizky Ramadhan','3271039012345678','2000-01-15','Laki-laki','0812-0003-0003','rizky.r@email.com','Jl. Anggrek No. 15, Bogor'),
('p4','Dewi Kartika','3271044321098765','1995-03-20','Perempuan','0813-0004-0004','dewi.k@email.com','Jl. Dahlia No. 8, Bekasi'),
('p5','Agus Purnomo','3271058765432109','1978-11-07','Laki-laki','0813-0005-0005','agus.p@email.com','Jl. Kenanga No. 22, Tangerang'),
('p6','Nurul Hidayah','3271062109876543','1992-07-14','Perempuan','0814-0006-0006','nurul.h@email.com','Jl. Seruni No. 3, Jakarta Barat'),
('p7','Eko Prasetyo','3271073456789012','1988-02-28','Laki-laki','0814-0007-0007','eko.p@email.com','Jl. Cempaka No. 17, Depok'),
('p8','Linda Susanti','3271087890123456','1997-09-03','Perempuan','0815-0008-0008','linda.s@email.com','Jl. Flamboyan No. 11, Bogor'),
('p9','Hendra Gunawan','3271091234560987','1975-06-18','Laki-laki','0815-0009-0009','hendra.g@email.com','Jl. Bougenville No. 6, Jakarta Timur'),
('p10','Yuliana Putri','3271105678904321','2002-12-30','Perempuan','0816-0010-0010','yuliana.p@email.com','Jl. Kamboja No. 9, Tangerang Selatan'),
('p11','Bambang Wijaya','3271119012348765','1970-04-05','Laki-laki','0816-0011-0011','bambang.w@email.com','Jl. Tulip No. 14, Bekasi Utara'),
('p12','Fitri Rahayu','3271123456782109','1998-08-19','Perempuan','0817-0012-0012','fitri.r@email.com','Jl. Kenari No. 2, Jakarta Pusat');

-- ============================================================
-- DATA: pendaftaran
-- ============================================================
INSERT INTO `pendaftaran` (`id`,`no_reg`,`pasien_id`,`pasien_nama`,`layanan_id`,`layanan_nama`,`dokter_id`,`dokter_nama`,`tanggal`,`keluhan`,`status`) VALUES
('reg1','REG-2025-1001','p1','Budi Santoso','l1','Poli Umum','d1','dr. Ahmad Santoso',CURDATE(),'Demam dan batuk sudah 3 hari, disertai pilek dan sakit tenggorokan.','Menunggu'),
('reg2','REG-2025-1002','p2','Sri Wahyuni','l3','Poli Anak','d2','dr. Siti Aminah, Sp.A',CURDATE(),'Anak demam tinggi 39 derajat, tidak mau makan, rewel sejak kemarin.','Diproses'),
('reg3','REG-2025-1003','p3','Rizky Ramadhan','l2','Poli Gigi','d3','drg. Budi Wijaya',CURDATE(),'Sakit gigi geraham kanan bawah, sudah 2 hari terasa berdenyut.','Selesai'),
('reg4','REG-2025-1004','p4','Dewi Kartika','l7','Poli Kandungan','d6','dr. Dewi Lestari, Sp.OG',CURDATE(),'Kontrol kehamilan 8 bulan, ingin USG dan konsultasi persiapan persalinan.','Menunggu'),
('reg5','REG-2025-1005','p5','Agus Purnomo','l1','Poli Umum','d4','dr. Heru Prasetyo',CURDATE(),'Kontrol tekanan darah tinggi, minta resep obat rutin.','Diproses'),
('reg6','REG-2025-1006','p6','Nurul Hidayah','l8','Poli Mata','d7','dr. Fajar Nugroho, Sp.M',CURDATE(),'Mata sering kabur dan perih saat menatap layar komputer terlalu lama.','Menunggu'),
('reg7','REG-2025-0998','p7','Eko Prasetyo','l4','Laboratorium','d1','dr. Ahmad Santoso',CURDATE()-INTERVAL 1 DAY,'Cek darah lengkap dan gula darah puasa atas rujukan dokter.','Selesai'),
('reg8','REG-2025-0999','p8','Linda Susanti','l2','Poli Gigi','d8','drg. Ratna Sari',CURDATE()-INTERVAL 1 DAY,'Scaling dan pemeriksaan rutin gigi, karang gigi terasa menumpuk.','Selesai'),
('reg9','REG-2025-1000','p9','Hendra Gunawan','l1','Poli Umum','d4','dr. Heru Prasetyo',CURDATE()-INTERVAL 1 DAY,'Nyeri sendi lutut kanan, susah berjalan dan bengkak sejak seminggu.','Selesai'),
('reg10','REG-2025-0995','p10','Yuliana Putri','l3','Poli Anak','d2','dr. Siti Aminah, Sp.A',CURDATE()-INTERVAL 2 DAY,'Imunisasi rutin DPT dan konsultasi tumbuh kembang anak usia 18 bulan.','Selesai'),
('reg11','REG-2025-0996','p11','Bambang Wijaya','l5','Radiologi','d5','dr. Rina Kusuma, Sp.Rad',CURDATE()-INTERVAL 2 DAY,'Rontgen dada atas permintaan dokter, kontrol paru-paru.','Selesai'),
('reg12','REG-2025-0997','p12','Fitri Rahayu','l7','Poli Kandungan','d6','dr. Dewi Lestari, Sp.OG',CURDATE()-INTERVAL 2 DAY,'Konsultasi menstruasi tidak teratur sudah 3 bulan, disertai nyeri perut.','Selesai');

-- ============================================================
-- DATA: rekam_medis
-- ============================================================
INSERT INTO `rekam_medis` (`id`,`tanggal`,`pasien_id`,`pasien_nama`,`dokter_id`,`dokter_nama`,`layanan_nama`,`diagnosis`,`anamnesis`,`pemeriksaan_fisik`,`tekanan_darah`,`nadi`,`suhu`,`tinggi_badan`,`berat_badan`,`tindakan`,`resep`,`catatan`) VALUES
('rm1',CURDATE()-INTERVAL 2 DAY,'p3','Rizky Ramadhan','d3','drg. Budi Wijaya','Poli Gigi',
 'Karies gigi molar kanan bawah grade II',
 'Pasien mengeluh nyeri berdenyut pada gigi geraham kanan bawah sejak 2 hari yang lalu, nyeri memberat saat makan.',
 'Tekanan darah: 120/80 mmHg, Nadi: 80x/mnt, Suhu: 36.5°C',
 '120/80','80','36.5','175','70',
 'Penambalan gigi dengan komposit resin, pembersihan kavitas',
 'Asam Mefenamat 500mg 3x1, Amoxicillin 500mg 3x1 (5 hari)',
 'Pasien diminta kontrol 1 minggu lagi untuk cek kondisi tambalan.'),

('rm2',CURDATE()-INTERVAL 1 DAY,'p7','Eko Prasetyo','d1','dr. Ahmad Santoso','Poli Umum',
 'Diabetes Melitus Tipe 2 terkontrol',
 'Pasien datang untuk kontrol gula darah rutin. Tidak ada keluhan berarti. Patuh minum obat.',
 'Tekanan darah: 130/85 mmHg, Nadi: 78x/mnt, Suhu: 36.7°C. GDS: 145 mg/dL',
 '130/85','78','36.7','168','75',
 'Pemeriksaan darah lengkap, Konsultasi diet',
 'Metformin 500mg 2x1 (30 hari), Glibenklamid 5mg 1x1 pagi',
 'Gula darah masih dalam batas terkontrol. Diet rendah karbohidrat dijaga. Kontrol 1 bulan lagi.'),

('rm3',CURDATE()-INTERVAL 1 DAY,'p9','Hendra Gunawan','d4','dr. Heru Prasetyo','Poli Umum',
 'Osteoarthritis genu dextra ringan',
 'Pasien laki-laki 50 tahun mengeluh nyeri lutut kanan sejak 1 minggu. Nyeri terutama saat naik tangga. Bengkak minimal.',
 'Tekanan darah: 145/90 mmHg, Nadi: 82x/mnt, Suhu: 36.8°C. ROM lutut kanan terbatas, krepitasi (+)',
 '145/90','82','36.8','170','88',
 'Fisioterapi, Konseling pengurangan berat badan',
 'Na Diclofenac 50mg 2x1 (seminggu), Ranitidine 150mg 2x1, Kalsium 500mg 1x1',
 'Dirujuk rontgen lutut kanan. Disarankan kompres air hangat, mengurangi aktivitas naik tangga berlebihan.'),

('rm4',CURDATE()-INTERVAL 2 DAY,'p10','Yuliana Putri','d2','dr. Siti Aminah, Sp.A','Poli Anak',
 'Anak sehat, imunisasi lengkap sesuai usia',
 'Orang tua membawa anak usia 18 bulan untuk imunisasi DPT lanjutan dan kontrol tumbuh kembang.',
 'BB: 10.5 kg, PB: 80 cm. Nadi: 110x/mnt, Suhu: 36.5°C. Reflek normal.',
 '-','110','36.5','80','10.5',
 'Imunisasi DPT-HB-Hib booster, Vitamin A',
 'Paracetamol sirup 120mg/5ml - bila demam 3x sehari',
 'Tumbuh kembang anak sesuai usia. Anjurkan stimulasi bicara dan motorik halus. Jadwal imunisasi berikutnya usia 24 bulan.'),

('rm5',CURDATE()-INTERVAL 2 DAY,'p12','Fitri Rahayu','d6','dr. Dewi Lestari, Sp.OG','Poli Kandungan',
 'Oligomenorea, suspek PCOS',
 'Pasien wanita 27 tahun mengeluh menstruasi tidak teratur sejak 3 bulan. Siklus 35-60 hari. Disertai nyeri perut dan jerawat.',
 'Tekanan darah: 110/70 mmHg, Nadi: 76x/mnt, Suhu: 36.6°C. Abdomen: supel, NT(-)',
 '110/70','76','36.6','160','58',
 'USG transvaginal, Pemeriksaan hormon FSH, LH, Estrogen',
 'Asam folat 400mcg 1x1',
 'Hasil USG menunjukkan gambaran ovarium polikistik. Disarankan konsultasi lebih lanjut dan cek hormon lengkap.');

-- ============================================================
-- DATA: obat
-- ============================================================
INSERT INTO `obat` (`id`,`nama`,`kategori`,`satuan`,`stok`,`harga`,`status`) VALUES
('o1','Paracetamol 500mg','Analgesik','Tablet',500,2000,'Tersedia'),
('o2','Amoxicillin 500mg','Antibiotik','Kapsul',300,5000,'Tersedia'),
('o3','Antasida Doen','Antasida','Tablet',200,1500,'Tersedia'),
('o4','Cetirizine 10mg','Antihistamin','Tablet',150,3000,'Tersedia'),
('o5','Metformin 500mg','Antidiabetik','Tablet',0,4000,'Habis'),
('o6','Asam Mefenamat 500mg','Analgesik/NSAID','Tablet',400,3500,'Tersedia'),
('o7','Glibenklamid 5mg','Antidiabetik','Tablet',250,2500,'Tersedia'),
('o8','Na Diclofenac 50mg','NSAID','Tablet',300,4500,'Tersedia'),
('o9','Ranitidine 150mg','Antasida/H2 Blocker','Tablet',200,3000,'Tersedia'),
('o10','Kalsium Laktat 500mg','Suplemen','Tablet',180,5000,'Tersedia'),
('o11','Paracetamol Sirup 120mg/5ml','Analgesik','Botol',80,15000,'Tersedia'),
('o12','Asam Folat 400mcg','Vitamin/Suplemen','Tablet',350,1000,'Tersedia'),
('o13','Vitamin C 500mg','Vitamin','Tablet',500,2500,'Tersedia'),
('o14','OBH Combi Sirup','Antitusif','Botol',60,28000,'Tersedia'),
('o15','Salbutamol 4mg','Bronkodilator','Tablet',120,3500,'Tersedia'),
('o16','Omeprazole 20mg','PPI','Kapsul',0,8000,'Habis'),
('o17','Amlodipine 5mg','Antihipertensi','Tablet',280,6000,'Tersedia'),
('o18','Captopril 25mg','Antihipertensi','Tablet',220,4000,'Tersedia'),
('o19','Vitamin B Complex','Vitamin','Tablet',400,3000,'Tersedia'),
('o20','Chlorpheniramine 4mg (CTM)','Antihistamin','Tablet',600,1000,'Tersedia');

-- ============================================================
-- DATA: billing + billing_item
-- ============================================================
INSERT INTO `billing` (`id`,`no_bill`,`pasien_id`,`pasien_nama`,`pendaftaran_id`,`layanan_nama`,`dokter_nama`,`tanggal`,`total_biaya`,`metode_pembayaran`,`status`) VALUES
('b1','BILL-2025-001','p1','Budi Santoso','reg1','Poli Umum','dr. Ahmad Santoso',CURDATE(),145000,'Tunai','Lunas'),
('b2','BILL-2025-002','p2','Sri Wahyuni','reg2','Poli Anak','dr. Siti Aminah, Sp.A',CURDATE(),165000,NULL,'Belum Lunas'),
('b3','BILL-2025-003','p3','Rizky Ramadhan','reg3','Poli Gigi','drg. Budi Wijaya',CURDATE(),460000,'Transfer Bank','Lunas'),
('b4','BILL-2025-004','p4','Dewi Kartika','reg4','Poli Kandungan','dr. Dewi Lestari, Sp.OG',CURDATE(),380000,NULL,'Belum Lunas'),
('b5','BILL-2025-005','p7','Eko Prasetyo','reg7','Laboratorium','dr. Ahmad Santoso',CURDATE()-INTERVAL 1 DAY,590000,'BPJS','Lunas'),
('b6','BILL-2025-006','p8','Linda Susanti','reg8','Poli Gigi','drg. Ratna Sari',CURDATE()-INTERVAL 1 DAY,320000,'Debit','Lunas'),
('b7','BILL-2025-007','p9','Hendra Gunawan','reg9','Poli Umum','dr. Heru Prasetyo',CURDATE()-INTERVAL 1 DAY,341000,'Tunai','Lunas'),
('b8','BILL-2025-008','p10','Yuliana Putri','reg10','Poli Anak','dr. Siti Aminah, Sp.A',CURDATE()-INTERVAL 2 DAY,280000,'Tunai','Lunas'),
('b9','BILL-2025-009','p11','Bambang Wijaya','reg11','Radiologi','dr. Rina Kusuma, Sp.Rad',CURDATE()-INTERVAL 2 DAY,195000,'Transfer Bank','Lunas'),
('b10','BILL-2025-010','p12','Fitri Rahayu','reg12','Poli Kandungan','dr. Dewi Lestari, Sp.OG',CURDATE()-INTERVAL 2 DAY,410000,'Debit','Lunas');

INSERT INTO `billing_item` (`billing_id`,`nama`,`jumlah`,`harga`) VALUES
('b1','Biaya Konsultasi',1,100000),('b1','Paracetamol 500mg',10,2000),('b1','Vitamin C 500mg',10,2500),
('b2','Biaya Konsultasi Anak',1,150000),('b2','Paracetamol Sirup',1,15000),
('b3','Biaya Konsultasi Gigi',1,120000),('b3','Tambal Gigi Komposit',1,250000),('b3','Asam Mefenamat 500mg',10,3500),('b3','Amoxicillin 500mg',15,5000),
('b4','Biaya Konsultasi OG',1,200000),('b4','USG Obstetri',1,150000),('b4','Asam Folat 400mcg',30,1000),
('b5','Darah Lengkap',1,85000),('b5','Gula Darah Puasa',1,35000),('b5','HbA1c',1,120000),('b5','Metformin 500mg',60,4000),('b5','Glibenklamid 5mg',30,2500),
('b6','Biaya Konsultasi Gigi',1,120000),('b6','Scaling Gigi',1,200000),
('b7','Biaya Konsultasi',1,100000),('b7','Na Diclofenac 50mg',14,4500),('b7','Ranitidine 150mg',14,3000),('b7','Kalsium Laktat 500mg',30,5000),
('b8','Biaya Konsultasi Anak',1,150000),('b8','Imunisasi DPT-HB-Hib',1,100000),('b8','Vitamin A',1,15000),('b8','Paracetamol Sirup',1,15000),
('b9','Rontgen Thorax PA',1,120000),('b9','Biaya Baca Dokter',1,75000),
('b10','Biaya Konsultasi OG',1,200000),('b10','USG Transvaginal',1,180000),('b10','Asam Folat 400mcg',30,1000);

-- ============================================================
-- DATA: admin_users
-- Password disimpan plaintext untuk demo.
-- Di produksi, WAJIB diganti dengan bcrypt hash (password_hash di PHP).
-- ============================================================
INSERT INTO `admin_users` (`id`,`nama`,`username`,`password`,`role`,`hak_akses`,`status`) VALUES
('u1','Super Administrator','admin','admin123','Superadmin','["dashboard","pasien","dokter","layanan","pendaftaran","jadwal","rekammedis","obat","pesan","billing","users"]','Aktif'),
('u2','Staf Administrasi','staf','staf123','Administrasi','["dashboard","pasien","pendaftaran","billing"]','Aktif'),
('u3','Perawat Jaga','perawat','perawat123','Perawat','["dashboard","pasien","rekammedis","jadwal"]','Aktif'),
('u4','dr. Ahmad Santoso','dokter1','dokter123','Dokter','["dashboard","pasien","rekammedis","jadwal"]','Aktif'),
('u5','Kasir Klinik','kasir','kasir123','Kasir','["dashboard","billing","pasien"]','Aktif');

-- ============================================================
-- VIEWS: berguna untuk laporan & dashboard
-- ============================================================

-- Ringkasan billing per hari
CREATE OR REPLACE VIEW `v_pendapatan_harian` AS
SELECT
  tanggal,
  COUNT(*) AS total_transaksi,
  SUM(CASE WHEN status='Lunas' THEN total_biaya ELSE 0 END) AS pendapatan_lunas,
  SUM(CASE WHEN status='Belum Lunas' THEN total_biaya ELSE 0 END) AS piutang
FROM billing
GROUP BY tanggal
ORDER BY tanggal DESC;

-- Kunjungan per dokter
CREATE OR REPLACE VIEW `v_kunjungan_dokter` AS
SELECT
  d.id, d.nama AS dokter, d.spesialisasi,
  COUNT(p.id) AS total_kunjungan
FROM dokter d
LEFT JOIN pendaftaran p ON p.dokter_id = d.id
GROUP BY d.id, d.nama, d.spesialisasi
ORDER BY total_kunjungan DESC;

-- Rekam medis lengkap (join pasien + dokter)
CREATE OR REPLACE VIEW `v_rekam_medis_lengkap` AS
SELECT
  rm.*,
  p.nik, p.ttl, p.jk, p.telepon AS pasien_telepon, p.alamat,
  d.spesialisasi
FROM rekam_medis rm
JOIN pasien  p ON p.id = rm.pasien_id
LEFT JOIN dokter   d ON d.id = rm.dokter_id;

-- Stok obat hampir habis (< 50)
CREATE OR REPLACE VIEW `v_obat_menipis` AS
SELECT * FROM obat WHERE stok < 50 ORDER BY stok ASC;
